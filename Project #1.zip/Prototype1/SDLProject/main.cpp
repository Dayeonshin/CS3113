#define GL_SILENCE_DEPRECATION

#ifdef _WINDOWS
#include <GL/glew.h>
#endif

#include <vector>
#include <SDL.h>
#include <SDL_opengl.h>
#include <SDL_image.h>
#include "glm/mat4x4.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "ShaderProgram.h"

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#include "Entity.h"

SDL_Window* displayWindow;
bool gameIsRunning = true;

ShaderProgram program;
glm::mat4 viewMatrix, modelMatrix, projectionMatrix;

Entity player;
Entity* objects;
Entity* platform;
int objectUsed = 0;
int objectCount;
bool fail = false;
bool success = false;

GLuint fontTextureID;

GLuint LoadTexture(const char* filePath)
{
    int w, h, n;
    unsigned char* image = stbi_load(filePath, &w, &h, &n, STBI_rgb_alpha);

    if (image == NULL) {
        std::cout << "Unable to load image. Make sure the path is correct\n";
        assert(false);
    }

    GLuint textureID;
    glGenTextures(1, &textureID);
    glBindTexture(GL_TEXTURE_2D, textureID);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

    stbi_image_free(image);
    return textureID;
}

void Initialize()
{
    SDL_Init(SDL_INIT_VIDEO);
    displayWindow = SDL_CreateWindow("SAVE THE EGG", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 640, 480, SDL_WINDOW_OPENGL);
    SDL_GLContext context = SDL_GL_CreateContext(displayWindow);
    SDL_GL_MakeCurrent(displayWindow, context);

#ifdef _WINDOWS
    glewInit();
#endif

    glViewport(0, 0, 640, 480);

    program.Load("shaders/vertex_textured.glsl", "shaders/fragment_textured.glsl");
    fontTextureID = LoadTexture("font.png");

    player.textureID = LoadTexture("ball.png");
    player.position = glm::vec3(1, 5, 0);
    player.acceleration = glm::vec3(0, -9.81f, 0);
    player.entityType = ME;

    objects = new Entity[objectCount = 100];
    
    for (int i = 0; i < 16; i++) {
        objects[objectUsed].position = glm::vec3(-9.0f + 1.5f + i * 1.0f, -4.5f + 0.5f, 0);
        objectUsed++;
    }
    
    for (int i = -2; i < 1; i++) {
        objects[objectUsed].position = glm::vec3(-5.0f + 1.5f + i * 1.0f, -1.0f + 0.5f, 0);
        objectUsed++;
    }
    
    for (int i = 4; i <8; i++) {
        objects[objectUsed].position = glm::vec3(-5.0f + 1.5f + i * 1.0f, -1.0f + 0.5f, 0);
        objectUsed++;
    }

    GLuint rocktexture = LoadTexture("olive.png");
    for (int i = 0; i < objectUsed; i++) {
        objects[i].textureID = rocktexture;
        objects[i].entityType = ROCK;
    }

    for (int i = 4; i < 7; i++) {
        objects[i].textureID  = LoadTexture("matte-Yellow.jpg");
        objects[i].entityType  = PLATFORM;
        platform = &objects[i];
    }

    viewMatrix = glm::mat4(1.0f);
    modelMatrix = glm::mat4(1.0f);
    projectionMatrix = glm::ortho(-8.0f, 8.0f, -4.5f, 4.5f, -1.0f, 1.0f);

    program.SetProjectionMatrix(projectionMatrix);
    program.SetViewMatrix(viewMatrix);
    program.SetColor(1.0f, 1.0f, 1.0f, 1.0f);

    glUseProgram(program.programID);

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
}

void DrawText(ShaderProgram* program, GLuint fontTextureID, std::string text, float size, float spacing, glm::vec3 position)
{
    float width = 1.0f / 16.0f;
    float height = 1.0f / 16.0f;

    std::vector<float> vertices;
    std::vector<float> texCoords;

    for (int i = 0; i < text.size(); i++)
    {
        int index = (int)text[i];

        float u = (float)(index % 16) / 16.0f;
        float v = (float)(index / 16) / 16.0f;

        texCoords.insert(texCoords.end(), { u, v + height, u + width, v + height, u + width, v, u, v + height, u + width, v, u, v });

        float offset = (size + spacing) * i;
        vertices.insert(vertices.end(), {   offset + (-0.5f * size), (-0.5f * size),
                                            offset + (0.5f * size), (-0.5f * size),
                                            offset + (0.5f * size), (0.5f * size),
                                            offset + (-0.5f * size), (-0.5f * size),
                                            offset + (0.5f * size), (0.5f * size),
                                            offset + (-0.5f * size), (0.5f * size) });

        glm::mat4 modelMatrix = glm::mat4(1.0f);
        modelMatrix = glm::translate(modelMatrix, position);
        program->SetModelMatrix(modelMatrix);

        glBindTexture(GL_TEXTURE_2D, fontTextureID);
        glVertexAttribPointer(program->positionAttribute, 2, GL_FLOAT, false, 0, vertices.data());
        glEnableVertexAttribArray(program->positionAttribute);

        glVertexAttribPointer(program->texCoordAttribute, 2, GL_FLOAT, false, 0, texCoords.data());
        glEnableVertexAttribArray(program->texCoordAttribute);

        glDrawArrays(GL_TRIANGLES, 0, vertices.size() / 2.0f);
        glDisableVertexAttribArray(program->positionAttribute);
        glDisableVertexAttribArray(program->texCoordAttribute);
    }
}

void ProcessInput()
{
    SDL_Event event;
    while (SDL_PollEvent(&event)) {
        switch (event.type) {
        case SDL_QUIT:
        case SDL_WINDOWEVENT_CLOSE:
            gameIsRunning = false;
            break;

        case SDL_KEYDOWN:
            switch (event.key.keysym.sym) {
            case SDLK_SPACE:
                // Some sort of action
                break;
            }
            break;
        }
    }

    const Uint8* keys = SDL_GetKeyboardState(NULL);

    if (keys[SDL_SCANCODE_RIGHT])
    {
        player.acceleration.x = 1.0;
    }
    else if (keys[SDL_SCANCODE_LEFT])
    {
        player.acceleration.x = -1.0;
    }
    else
    {
        player.acceleration.x = 0.0;
    }

    if (keys[SDL_SCANCODE_UP])
    {
        player.acceleration.y = 0.5;
    }
    else
    {
        player.acceleration.y = -0.5;
    }


    if (keys[SDL_SCANCODE_R] && fail)
    {
        player.position = glm::vec3(1, 5, 0);
        player.velocity = glm::vec3(0);
        player.acceleration = glm::vec3(0, -9.81f, 0);
        player.lastCollision = NONE;

        fail = false;
        success = false;
    }
}

#define FIXED_TIMESTEP 0.0166666f
float lastTicks = 0;
float accumulator = 0.0f;

void Update()
{
    if (player.lastCollision != NONE) {
        fail = true;
        success = false;
        if (player.lastCollision == PLATFORM) {
            success = true;
        }
        return;
    }

    float ticks = (float)SDL_GetTicks() / 1000.0f;
    float deltaTime = ticks - lastTicks;
    lastTicks = ticks;

    deltaTime += accumulator;
    if (deltaTime < FIXED_TIMESTEP) {
        accumulator = deltaTime;
        return;
    }

    while (deltaTime >= FIXED_TIMESTEP) {
        // Update. Notice it's FIXED_TIMESTEP. Not deltaTime
        player.Update(FIXED_TIMESTEP, objects, objectUsed);

        deltaTime -= FIXED_TIMESTEP;
    }

    accumulator = deltaTime;

}

void Render()
{
    glClear(GL_COLOR_BUFFER_BIT);

    player.Render(&program);

    for (int i = 0; i < objectUsed; i++) {
        objects[i].Render(&program);
    }
    
    if (fail) {
        if (success) {
            DrawText(&program, fontTextureID, "Mission Successful", 0.5f, -0.2f, glm::vec3(-2, 2, 0));
        }
        else {
            DrawText(&program, fontTextureID, "Mission Failed", 0.5f, -0.2f, glm::vec3(-2, 2, 0));
        }
    }

    SDL_GL_SwapWindow(displayWindow);
}

void Shutdown()
{
    SDL_Quit();
}

int main(int argc, char* argv[])
{
    Initialize();

    while (gameIsRunning) {
        ProcessInput();
        Update();
        Render();
    }

    Shutdown();
    return 0;
}
